# effect-drizzle

This project is based on Lucas Barake's [effect-monorepo database](https://github.com/lucas-barake/effect-monorepo/tree/main/packages/database) package.

Supported adapters:

- Bun SQLite
- libSQL
- libSQL Wasm
- Expo SQLite
- Postgres

## Installation

This package is not published to npm yet.

```bash
bun add github:HaukeSchnau/effect-drizzle
```

For local integration with Groundswell, use the pack/sync flow:

```bash
# in effect-drizzle
bun run pack:local
bun run pack:local:verify

# in Groundswell
bun run local:effect-drizzle:sync
bun run local:effect-drizzle:verify
```

`pack:local` writes:

- versioned tarball: `effect-drizzle-local-v<version>-<hash>.tgz`
- compatibility alias: `effect-drizzle-local.tgz`
- metadata: `effect-drizzle-local.json`

## Development

### Prerequisites

- Bun 1.3.10

Optional:

- Nix + direnv
- Just
- lefthook

If you use Nix, enter the dev shell before running Bun commands:

```bash
nix develop
bun install
bun --version # should print 1.3.10
```

### Setup

```bash
bun install
bunx lefthook install
```

### Checks

```bash
bun run check
bun run test:coverage
```

Run only sqlite/libsql integration:

```bash
bun run test:integration:sqlite
```

Run Postgres integration with a disposable Docker container:

```bash
bun run test:integration:postgres:docker
```

Expo adapter tests run through a compatibility shim in Node. Before releasing Expo-specific changes, run a manual Expo smoke test on device or simulator.

## Usage (Bun SQLite)

```ts
import * as BunRuntime from "@effect/platform-bun/BunRuntime";
import { makeService } from "@schnau/effect-drizzle/bun-sqlite";
import { type GenericDatabaseService } from "@schnau/effect-drizzle/generic-sqlite";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";
import { Effect, Layer, Redacted } from "effect";
import * as ServiceMap from "effect/ServiceMap";

const Todos = sqliteTable("todos", {
	id: integer("id").primaryKey({ autoIncrement: true }),
	title: text("title").notNull(),
	completed: integer("completed").notNull(),
});

const Schema = {
	todos: Todos,
};

type Schema = typeof Schema;

const Database = ServiceMap.Service<GenericDatabaseService<Schema>>("app/Database");

const DatabaseLive = Layer.scoped(
	Database,
	makeService(
		{
			url: Redacted.make(":memory:"),
			schema: Schema,
		},
		Database,
	),
);

const program = Effect.gen(function* () {
	const db = yield* Database;
	yield* db.execute((client) => client.insert(Todos).values({ title: "Ship tests", completed: 0 }));
	const rows = yield* db.execute((client) => client.select().from(Todos));
	yield* Effect.log(rows);
}).pipe(Effect.provide(DatabaseLive));

BunRuntime.runMain(program);
```
