# effect-drizzle

This project is based on Lucas Barake's [effect-monorepo database](https://github.com/lucas-barake/effect-monorepo/tree/main/packages/database) package.

I've added support for the following databases and made it generic for any Drizzle schema.

- libSQL (Wasm)
- Expo SQLite
- Bun SQLite

## Installation

This package is not published to npm yet.

```bash
bun add github:HaukeSchnau/effect-drizzle
```

For local integration with Groundswell, use the canonical pack/sync flow instead of ad-hoc installs:

```bash
# in effect-drizzle
bun run pack:local
bun run pack:local:verify

# in Groundswell
bun run local:effect-drizzle:sync
bun run local:effect-drizzle:verify
```

`pack:local` writes:

- versioned tarball: `effect-drizzle-local-v<version>-<hash>.tgz`
- compatibility alias: `effect-drizzle-local.tgz`
- metadata: `effect-drizzle-local.json`

## Usage (Bun SQLite)

```ts
import * as BunRuntime from "@effect/platform-bun/BunRuntime";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";
import { Redacted, Effect } from "effect";
import * as BunDatabase from "effect-drizzle/bun-sqlite";

const Schema = {
 todos: sqliteTable("todos", {
  id: integer("id").primaryKey(),
  title: text("title").notNull(),
  completed: integer("completed").notNull(),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
 }),
};

const Database = BunDatabase.factory<typeof Schema>();

const DatabaseLive = Database.layer({
 url: Redacted.make(":memory:"),
 schema: Schema,
});

const program = Effect.gen(function* () {
 const db = yield* Database.Database;

 yield* db.transaction(
  Effect.fnUntraced(function* (tx) {
   yield* tx((client) =>
    client.insert(Schema.todos).values({
     title: "Do something",
     completed: 0,
     createdAt: Date.now(),
     updatedAt: Date.now(),
    }),
   );

   const result = yield* tx((client) =>
    client.select().from(Schema.todos),
   );

   yield* Effect.log(result);
  }),
 );
}).pipe(Effect.provide(DatabaseLive));

BunRuntime.runMain(program);
```
